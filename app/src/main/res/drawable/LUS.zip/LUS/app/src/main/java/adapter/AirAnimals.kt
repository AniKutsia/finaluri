package adapter

data class AirAnimals(

    var id: String? = null,
    var title: String? = null,
    var description: String? = null,
    var imageUrl:String? = null
)

