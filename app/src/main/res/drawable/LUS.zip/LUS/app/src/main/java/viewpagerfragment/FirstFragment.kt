package viewpagerfragment

import androidx.fragment.app.Fragment
import com.example.lus.R

class FirstFragment:Fragment(R.layout.firstviewpagerfragment) {
}