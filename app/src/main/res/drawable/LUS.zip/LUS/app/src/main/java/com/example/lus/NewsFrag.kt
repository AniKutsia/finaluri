package com.example.lus


data class NewsFrag(
    var id: String? = null,
    var title: String? = null,
    var description: String? = null,
    var imageUrl:String? = null
)
