package adapter

data class LandAnimal(
    var id: String? = null,
    var title: String? = null,
    var description: String? = null,
    var imageUrl:String? = null
)
