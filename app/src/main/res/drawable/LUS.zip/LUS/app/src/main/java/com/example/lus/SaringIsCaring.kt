package com.example.lus

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class SaringIsCaring : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_saring_is_caring)
    }
}