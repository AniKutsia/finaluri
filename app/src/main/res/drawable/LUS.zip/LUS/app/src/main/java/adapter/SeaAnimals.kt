package adapter

data class SeaAnimals(
    var id: String? = null,
    var title: String? = null,
    var description: String? = null,
    var imageUrl:String? = null

)
